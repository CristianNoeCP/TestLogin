export class Booking{
    constructor(
        
        public bookingId : string,
        public Cliente : string,
        public Fecha_de_Creacion : string,
        public Direccion : string,
        public Precio : string
    ){}
}
