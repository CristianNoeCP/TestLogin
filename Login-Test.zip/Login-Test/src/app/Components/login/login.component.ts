import { Component, OnInit } from '@angular/core';

import { TutenService } from './../../Services/tuten.service';
import {Router} from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.sass']
})
export class LoginComponent implements OnInit {
public mail : string;
public pass : string;

constructor(private service: TutenService,private router: Router) { 

}

  ngOnInit() {
  }
   login()
   {
     this.service.loginUser(this.mail,this.pass).subscribe(
       result => {
         localStorage.setItem("token_tuten",result.sessionTokenBck);
         localStorage.setItem("email",this.mail);
         this.router.navigate(['/Table']);
         console.log("entre",result.sessionTokenBck);
       },
       error => {
           console.log(<any>error);
       }
   );
 
   }


}
