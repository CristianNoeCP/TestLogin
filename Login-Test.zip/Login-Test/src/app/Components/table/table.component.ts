import { Component, OnInit } from '@angular/core';
import { TutenService } from './../../Services/tuten.service';
import {Router} from "@angular/router";
import {Booking} from './../../models/booking';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.sass']
})
export class TableComponent implements OnInit {
  public bookingSource: Object;
  public Bookings : Array<Booking>;
  public Bookingsfiltrar : Array<Booking>;
  public filtroBooking : string;

  constructor(private service: TutenService,private router: Router) { 
    this.Bookings = [];
  }


  ngOnInit() {
    if (localStorage.getItem("token_tuten") != null) {
      this.service.consultarBookings().subscribe(
        result => {
          
          for (const prop in result) 
          {           
            let fecha = new Date(result[prop].bookingTime);
            let fechamostrar = fecha.toDateString() + " "+ fecha.toTimeString();
            this.Bookings.push (new Booking(result[prop].bookingId,result[prop].tutenUserClient.firstName+" "+result[prop].tutenUserClient.lastName ,fechamostrar,result[prop].locationId.streetAddress,result[prop].bookingPrice));            
          }
          this.Bookingsfiltrar = this.Bookings;
        },
        error => {
          console.log(<any>error);
        }
      );
    }
    else {
      this.router.navigate(['/login']);
    } 
  }
  filtro() {
let query = this.filtroBooking;
    this.Bookings=this.Bookingsfiltrar.filter(function(Bookingfil) {
       return (Bookingfil.Cliente.toLowerCase().indexOf(query.toLowerCase()) > -1) || (Bookingfil.Direccion.toLowerCase().indexOf(query.toLowerCase()) > -1) || (Bookingfil.Fecha_de_Creacion.toLowerCase().indexOf(query.toLowerCase()) > -1) || (Bookingfil.bookingId.toString().indexOf(query) > -1)|| (Bookingfil.Precio.toString().indexOf(query) > -1);
    })
  }
  cerrarsesion()
  {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

}
